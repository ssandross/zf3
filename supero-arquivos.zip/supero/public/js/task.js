function task() {
}

task.prototype = {
	setValue : function(id) {
		$('#idTask').val(id);
	},
	deleteTask: function() {
		
		var id = $('#idTask').val();
		
		 $.ajax({
            url: '/delete',
            method: 'post',
            data: { id : id },
            dataType: 'json',
            success: function (json) {
            	location.reload();
            },
            error: function () {
                alert('error');
            }
        });
	},
	statusTask: function (id) {
		
		var idButton = 'statusTask-'+id;
		var idIcon = 'glyphicon-'+id;
		var idStatus = 'status-'+id;
		
		 $.ajax({
           url: '/status',
           method: 'post',
           data: { 
        	   id : id
           },
           dataType: 'json',
           success: function (json) {
        	   
        	   if (json.status == 2) {
        		   $('#'+idButton).toggleClass('btn-success btn-warning');
        		   $('#'+idIcon).toggleClass('glyphicon-download glyphicon-upload');
        		   $('#'+idStatus).text('Concluido');
        	   } else {
        		   $('#'+idButton).toggleClass('btn-warning btn-success');
        		   $('#'+idIcon).toggleClass('glyphicon-upload glyphicon-download');
        		   $('#'+idStatus).text('Aberto');
        	   }
        	   
           },
           error: function () {
               alert('error');
           }
       });
		
	}

}

var task = new task();