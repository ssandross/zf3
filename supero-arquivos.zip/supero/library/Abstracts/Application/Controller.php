<?php
namespace Library\Abstracts\Application;

use Zend\Mvc\MvcEvent;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Stdlib\RequestInterface as Request;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\View\Model\ViewModel;
use Zend\Session;

class Controller extends AbstractActionController
{

    protected $_view;

    protected $_serviceLocator;
    
    protected $_isAllowNotLoggedIn = true;
    
    protected $_loggedUser;

    /**
     *
     * {@inheritdoc}
     * @see \Zend\Mvc\Controller\AbstractActionController::onDispatch()
     */
    public function onDispatch(MvcEvent $e)
    {
        $this->_serviceLocator = $e->getApplication()->getServiceManager();
        
        $response = $this->_init();
        if (! empty($response)) {
            $e->setResult($response);
            return $response;
        }
        
        return parent::onDispatch($e);
    }

    /**
     *
     * {@inheritdoc}
     * @see \Zend\Mvc\Controller\AbstractController::dispatch()
     */
    public function dispatch(Request $request, Response $response = null)
    {
    	$session = new Session\Container('auth_site');
    	$indicationSession = new Session\Container('indication');
    	
    	if (!$this->_isAllowNotLoggedIn && empty($session->data)){
    		
    		$response->setStatusCode(401);
    		$url = str_replace('=', '', base64_encode($request->getRequestUri()));
    		$urlRedir = 'http://'.$request->getUri()->getHost() . '/login?redir=' . $url;
    		$this->redirect()->toUrl($urlRedir);
    		$response->send();
    		return $response;
    	}
    	
    	if(isset($session->data)){
    		$this->_loggedUser = &$session->data;
    	}
    	
    	$this->_session = $session;
    	$this->_view = new ViewModel();
    	$this->_view->user = $session->data;
    	
    	return parent::dispatch($request, $response);
    }

    public function _init()
    {
    	$controllerName =$this->params('controller');
    	$actionName = $this->params('action');
    	
//     	echo '<pre>'; var_dump($controllerName); exit;
    }
    
    /**
     * @param string $date
     * @param string $dateFormat
     * @param string $actualFormat
     * @return date
     */
    public function formatDate($date, $dateFormat, $actualFormat)
    {
    	$formattedDate = \DateTime::createFromFormat($actualFormat, $date);
    	
    	return $formattedDate->format($dateFormat);
    }
    
    /**
     *
     * @param int $name
     * @return \Zend\Form\Form
     */
    protected function getForm($name)
    {
        return $this->_serviceLocator->get('FormElementManager')->get($name);
    }

}

