<?php

/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Application\Controller;

use Application\Model;
use Application\Form;
use Library\Abstracts\Application\Controller;
use Zend\View\Model\JsonModel;

class IndexController extends Controller {
	
	/**
	 *
	 * @var \Application\Model\TaskModel
	 */
	private $_model;
	
	/**
	 *
	 * @param Model\TaskModel $model        	
	 */
	public function __construct(Model\TaskModel $model) {
		$this->_model = $model;
	}
	
	/**
	 *
	 * {@inheritdoc}
	 *
	 * @see \Zend\Mvc\Controller\AbstractActionController::indexAction()
	 */
	public function indexAction() {
		$data = $this->_model->getAll ();
		
		$this->_view->data = $data;
		
		return $this->_view;
	}
	
	/**
	 */
	public function newAction() {
		$form = $this->getForm ( Form\TaskForm::class );
		
		if ($this->getRequest ()->isPost ()) {
			
			$postData = $this->getRequest ()->getPost ()->toArray ();
			$form->setData ( $postData );
			
			if ($form->isValid ()) {
				
				$params = $form->getInputFilter ()->getValues ();
				unset ( $params ['status'] );
				
				$this->_view->id = $this->_model->insertTask ( $params );
				
				$this->redirect ()->toUrl ( "/" );
				return $this->getResponse ();
			}
		}
		
		$this->_view->form = $form;
		
		return $this->_view;
	}
	
	/**
	 */
	public function statusAction() {
		$id = $this->getRequest ()->getPost ( 'id' );
		
		$dataTask = $this->_model->getTask($id);
		
		$status = $this->getStatus ( $dataTask['status']);
		
		$this->_model->updateStatus ( $id, $status );
		
		return new JsonModel ( [ 
				'response' => true,
				'message' => 'OK',
				'status' => $status
		] );
	}
	
	/**
	 */
	public function deleteAction() {
		$id = $this->getRequest ()->getPost ( 'id' );
		
		$this->_model->deleteTask ( $id );
		
		return new JsonModel ( [ 
				'response' => true,
				'message' => 'OK' 
		] );
	}
	
	/**
	 */
	public function editAction() {
		$id = $this->getRequest ()->getQuery ( 'id' );
		
		$data = $this->_model->getTask ( $id );
		
		$form = $this->getForm ( Form\TaskForm::class );
		
		if ($this->getRequest ()->isPost ()) {
			
			$postData = $this->getRequest ()->getPost ()->toArray ();
			$form->setData ( $postData );
			
			if ($form->isValid ()) {
				
				$params = $form->getInputFilter ()->getValues ();
				unset ( $params ['status'] );
				
				$this->_model->updateTask ( $id, $params );
				
				$this->redirect ()->toUrl ( "/" );
				return $this->getResponse ();
			}
		}
		
		$form->setData ( $data );
		
		$this->_view->form = $form;
		
		return $this->_view;
	}
	
	/**
	 *
	 * @param string $status        	
	 */
	protected function getStatus($status) {
		if ($status == 1)
			return 2;
		
		if ($status == 2)
			return 1;
		
		echo '<pre>';
		var_dump ( 'status-error' );
		exit ();
	}
}
