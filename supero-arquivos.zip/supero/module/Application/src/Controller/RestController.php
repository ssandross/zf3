<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Application\Model;
use Zend\View\Model\JsonModel;
use Zend\Diactoros\Response;

class RestController extends AbstractRestfulController {
	
	/**
	 *
	 * @var \Application\Model\TaskModel
	 */
	private $_model;
	
	/**
	 *
	 * @param Model\TaskModel $model        	
	 */
	public function __construct(Model\TaskModel $model) {
		$this->_model = $model;
	}
	
	/**
	 */
	public function indexAction() {
		echo '<pre>';
		var_dump ( 'aqui' );
		exit ();
	}
	
	/**
	 *
	 * @return \Zend\View\Model\JsonModel
	 */
	public function getAllAction() {

		$data = $this->_model->getAll();
		
		$this->response->getHeaders()->addHeaderLine('Content-type', 'application\json');
		
		return new JsonModel ( [ 
				'response' => true,
				'data' => $data
		] );
	}
	
	/**
	 * 
	 * @return \Zend\View\Model\JsonModel
	 */
	public function setTaskConcluidaAction() {
		
		$id = $this->getRequest ()->getQuery( 'id' );
		$statusIdConcluido = 2;
		
		$this->_model->updateStatus($id, $statusIdConcluido);
		
		return new JsonModel ( [
				'response' => true,
				'message' => 'Task concluida com sucesso'
		] );
	}
	
	/**
	 * 
	 * @return \Zend\View\Model\JsonModel
	 */
	public function setTaskAbertaAction(){
		
		$id = $this->getRequest ()->getQuery( 'id' );
		$statusIdabertaberta = 1;
		
		$this->_model->updateStatus($id, $statusIdabertaberta);
		
		return new JsonModel ( [
				'response' => true,
				'message' => 'Task aberta com sucesso'
		] );
		
	}
	
	/**
	 * 
	 * @return \Zend\View\Model\JsonModel
	 */
	public function deleteTaskAction(){
		
		$id = $this->getRequest ()->getQuery( 'id' );
		$statusIDeletado = 0;
		
		$this->_model->updateStatus($id, $statusIDeletado);
		
		return new JsonModel ( [
				'response' => true,
				'message' => 'Task deletada com sucesso'
		] );
	}
}