<?php

namespace Application\Form;

use Zend\Form\Element;
use Zend\Form\Form;
use Zend\InputFilter\InputFilter;
use Gabinete\Model;

/**
 *
 * @author Sandro
 *        
 */
class TaskForm extends Form {
	
	/**
	 *
	 * @param Model\TaskModel $model        	
	 */
	public function __construct() {
		parent::__construct ();
	}
	
	/**
	 *
	 * {@inheritdoc}
	 *
	 * @see \Zend\Form\Element::init()
	 */
	public function init() {
		$this->add ( [ 
				'name' => 'title',
				'type' => Element\Text::class,
				'attributes' => [ 
						'class' => 'form-control',
						'required' => 'required',
						'id' => 'title',
						'placeholder' => 'Título' 
				
				] 
		] );
		
		$this->add ( [ 
				'name' => 'status',
				'type' => Element\Select::class,
				'attributes' => [ 
						'class' => 'form-control',
						'id' => 'status',
						'value'  => 1,
				],
				'options' => [ 
						'empty_option' => 'Status',
						'value_options' => [ 
								'1' => 'Ativo',
								'2' => 'Concluído' 
						] 
				] 
		] );
		
		$this->add ( [ 
				'name' => 'description',
				'type' => Element\Textarea::class,
				'attributes' => [ 
						'class' => 'form-control',
						'required' => 'required',
						'id' => 'description',
						'placeholder' => 'Descrição' 
				
				] 
		] );
		
		$this->addInputFilter ();
	}
	
	/**
	 */
	protected function addInputFilter() {
		$inputFilter = new InputFilter ();
		
		$inputFilter->add ( [ 
				'name' => 'title',
				'required' => true 
		] );
		
		$inputFilter->add ( [ 
				'name' => 'description',
				'required' => true 
		] );
		
		$inputFilter->add ( [ 
				'name' => 'status',
				'required' => false 
		] );
		
		$this->setInputFilter ( $inputFilter );
	}
}