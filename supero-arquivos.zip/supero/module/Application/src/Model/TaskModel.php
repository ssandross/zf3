<?php
namespace Application\Model;

use Zend\Db\Sql\Expression;

/**
 *
 * @author Sandro
 *        
 */
class TaskModel extends \Library\Abstracts\Model
{

    /**
     * 
     * @return array
     */
    public function getAll()
    {
        $status = new Expression("CASE status WHEN status = 1 THEN 'Ativo' ELSE 'Concluído' END");
    	
    	$sql = $this->select()->from(['tas' => 'task'])
			        ->columns([
			        	'Id',
			        	'title',
			        	'description',
			        	'status' => $status,
			        	'status_id' => 'status'	
			        ])
			        ->order('tas.id DESC')
        			->where(['status != 0']);
        
        return $this->fetchAll($sql);
    }
    
    /**
     * 
     * @param int $id
     * @return mixed|array
     */
    public function getTask($id) {
    	$sql = $this->select()->from(['tas' => 'task'])
			    	->columns(['*'])
			    	->where ( ['Id' => (int) $id] );
    	
    	return $this->fetchRow($sql);
    }
    
    /**
     * 
     * @param array $params
     * @return mixed|NULL
     */
    public function insertTask($data) {
    	$data['creation_date'] = new Expression('NOW()');
    	
    	$sql = $this->insert()->into('task');
    	$sql->values($data);
    	
    	$cadastroId = $this->execute($sql)->getGeneratedValue();
    	return $cadastroId;
    }
    
    /**
     * 
     * @param array $data
     */
    public function updateTask($id, $data) {
    	
    	$data['edition_date'] = new Expression('NOW()');
    	
    	$sql = $this->update ( 'task' )
			    	->set($data)
			    	->where(['Id' => (int) $id]);
    	
//     	exit($sql->getSqlString());
    	
    	$this->execute($sql);
    	
    }
    
    /**
     * 
     * @param int $id
     */
    public function deleteTask($id) {
    	
    	$data['exclusion_date'] = new Expression('NOW()');
    	$data['status'] = 0;
    	
    	$sql = $this->update ( 'task' )
			    	->set($data)
			    	->where(['Id' => (int) $id]);
    	
//     	exit($sql->getSqlString());
    	
    	$this->execute($sql);
    	
    }
    
    /**
     * 
     * @param int $id
     * @param string $status
     */
    public function updateStatus($id, $status) {
    	
    	$data['conclusion_date'] = new Expression('NOW()');
    	$data['status'] = $status;
    	
    	$sql = $this->update ( 'task' )
			    	->set($data)
			    	->where(['Id' => (int) $id]);
    	
//     	exit($sql->getSqlString());
    	
    	$this->execute($sql);
    }
    
}